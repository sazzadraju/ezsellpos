<ul class="breadcrumb">
    <?php
    if ($breadcrumb) {
        echo $breadcrumb;
    }
    ?>
</ul>


<div class="content-i">
    <div class="content-box">
        <div class="row">
            <div class="col-lg-12">
                <?php
                if (!empty($stock_transfer_list)) {
                    ?>
                    <div class="element-wrapper">
                        <div class="top-btn full-box">
                            <div class="row">

                                <div class="col-md-3">
                                    <div class="form-group row">
                                        <label class="col-sm-12 col-form-label"
                                               for=""><?= lang('invoice_no') ?> </label>
                                        <div class="col-sm-12">
                                            <?php echo $stock_transfer_list[0]['invoice_no']; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group row">
                                        <label class="col-sm-12 col-form-label"
                                               for=""><?= lang('stock_transfer_date') ?> </label>
                                        <div class="col-sm-12">
                                            <?php echo $stock_transfer_list[0]['dtt_stock_mvt']; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group row">
                                        <label class="col-sm-12 col-form-label"
                                               for=""><?= lang('stock_transfer_reason') ?> </label>
                                        <div class="col-sm-12">
                                            <?php echo $stock_transfer_list[0]['notes']; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group row">
                                        <label class="col-sm-12 col-form-label"
                                               for=""><?= lang('download_doc') ?> </label>
                                        <div class="col-sm-12">
                                            <?php
                                            if (!empty($doc_list['file'])) {
                                                ?>
                                                <a href="<?php echo base_url() . 'public/uploads/stock_documents/' . $doc_list['file']; ?>"
                                                   download>
                                                    <button class="btn btn-success btn-xs"><i class="fa fa-download"
                                                                                              aria-hidden="true"></i>
                                                    </button>
                                                </a>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <button class="btn btn-primary pull-right" type="button" onclick="stock_print_view(<?=$stock_id?>)"><i
                                    class="fa fa-view"></i> <?= lang("print"); ?></button>
                                </div>
                            </div>
                        </div>
                        <div class="element-box full-box">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive" id="postList">
                                        <table id="mytable" class="table table-bordred table-striped">
                                            <thead>
                                            <tr>
                                                <th><?= lang('serial') ?></th>
                                                <th><?= lang('product') ?></th>
                                                <th><?= lang('attributes') ?></th>
                                                <th><?= lang('batch') ?></th>
                                                <th><?= lang('supplier') ?></th>
                                                <th><?= lang('expiration_date') ?></th>
                                                <th class="text-right"><?= lang('quantity') ?></th>
                                                <th class="text-right"><?= lang('purchase') . ' (' . set_currency() . ')'?></th>
                                                <th class="text-right"><?= lang('sale'). ' (' . set_currency() . ')' ?></th>
                                                <th class="text-right"><?= lang('total'). ' (' . set_currency() . ')' ?></th>

                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                            $i = 1;
                                            $tot_qty = 0;
                                            $total = 0;
                                            if (!empty($stock_transfer_list)) {
                                                foreach ($stock_transfer_list as $list) {
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $i; ?></td>
                                                        <td><?php echo $list['product_name'].'<br>('.$list['product_code'].')'; ?></td>
                                                        <td><?php echo $list['attribute_name']; ?></td>
                                                        <td><?php echo $list['batch_no']; ?></td>
                                                        
                                                        <td><?php echo $list['supplier_name']; ?></td>
                                                        <td><?php echo $list['expire_date']; ?></td>
                                                        <td class="text-right"><?php echo round($list['purchase_qty'],2); ?></td>
                                                        <td class="text-right"><?php echo round($list['purchase_price'],2); ?></td>
                                                        <td class="text-right"><?php echo round($list['selling_price_est'],2); ?></td>
                                                        <td class="text-right"><?php echo round(($list['purchase_qty'] * $list['purchase_price']),2); ?></td>
                                                    </tr>
                                                    <?php
                                                    $i++;
                                                    $tot_qty += $list['purchase_qty'];
                                                    $total += ($list['purchase_qty'] * $list['purchase_price']);
                                                }
                                            }
                                            ?>
                                            </tbody>
                                            <tfoot>
                                            <th class="text-right" colspan="6"><?= lang("total"); ?></th>
                                            <th class="text-right"><?= round($tot_qty,2); ?></th>
                                            <th colspan="3" class="text-right"><?= round($total,2); ?></th>
                                            </tfoot>
                                        </table>
                                        <div class="clearfix"></div>
                                        <?php echo $this->ajax_pagination->create_links(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                } else {
                    echo 'No data found';
                }
                ?>
            </div>
        </div>
    </div>
</div>
<div id="stockDetailsData" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="element-header margin-0">Stock Transfer Details</h6>
                <button type="button" class="btn btn-default pull-right" data-dismiss="modal" aria-hidden="true">Close
                </button>
                <button type="button" class="btn btn-default pull-right" onclick="sale_print()">Print</button>

            </div>
            <div class="modal-body">
                <div class="sale-view invoice_content" id="stock_view">

                </div>
            </div>

        </div>
    </div>
</div>

<script type="text/javascript">
    function stock_print_view(id) {
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url(); ?>stock/stock_transfer/stock_print_view' ,
            data:'id='+id,
            beforeSend: function () {
                $('.loading').show();
            },
            success: function (html) {
                $('#stock_view').html(html);
                $('.loading').fadeOut("slow");
                $('#stockDetailsData').modal('toggle');
            }
        });
    }
</script>

